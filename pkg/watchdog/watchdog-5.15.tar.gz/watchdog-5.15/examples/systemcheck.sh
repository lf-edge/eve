#!/bin/sh

# This checks quite some resources of the system. If for instance libc is
# destroyed you cannot start /bin/sh anymore.
# Courtesy of: Zygo Blaxell <zblaxell@linuxmaster.hungrycats.org>

exit 0
